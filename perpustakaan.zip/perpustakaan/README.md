# E-PERPUS
 Aplikasi perpustakaan sederhana ini dibuat menggunakan Template dari AdminLTE.io dan Menggunakan bahasa pemograman PHP MySQLi. <br> <br>
 Aplikasi ini bebas untuk dikembangkan lagi atau untuk bahan pembelajaran kalian bagi yang mau membuat aplikasi perpustakaan, mungkin bisa mengambil contoh dari aplikasi ini

# Akun Administrator
Username : admin
<br>
Password : admin

# Cara Instalasi
<ul>
     <li> Ekstrak arsip / file zip yang telah didownload </li>
     <li> Buka folder "e-perpus-main" </li>
     <li> Pindahkan semua file dan folder di dalam folder "e-perpus-main" ke dalam folder Localhost (htdocs) </li>
     <li> Buka XAMPP </li>
     <li> Start Module Apache dan Module MySQL </li>
     <li> Pilih aksi "Admin" pada Module MySQL untuk import database perpustakaan terlebih dahulu </li>
     <li> Jika sudah masuk ke phpMyAdmin buat sebuah basis data baru bernama "db_perpustakaan" atau bisa juga sesuai kalian masing masing </li>
     <li> Jika sudah dibuat, pilih basis data yang tadi kalian buat lalu pilih menu Import yang ada di bagian atas </li>
     <li> Pilih Choose File untuk mencari database mana yang akan di import ke basis data tersebut </li>
     <li> Jika sudah klik tombol kirim untuk meng-upload database yang dipilih </li>
     <li> Selanjutnya setting file koneksi.php yang terdapat di dalam folder Config </li>
     <li> Sesuaikan dengan setingan di localhost kalian masing masing </li>
     <li> Jika menurut kalian file koneksi.php sudah sesuai dengan setingan yang kalian gunakan, Selanjutnya kalian bisa langsung masuk ke Aplikasi nya </li>
     <li> Semoga Bermanfaat </li>
</ul>

# Terima Kasih
<ul>
    <li> AdminLTE </li>
    <li> PT. Pacifica Raya Technology </li>
    <li> Stackoverflow </li>
    <li> Google </li>
</ul>
