<?php
session_start();
//------------------------------::::::::::::::::::::------------------------------\\
// Dibuat oleh Muhamad Fathul Bari \\
//------------------------------::::::::::::::::::::------------------------------\\
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php
    include "config/koneksi.php";

    $sql = mysqli_query($koneksi, "SELECT * FROM identitas");
    $row1 = mysqli_fetch_assoc($sql);
    ?>
    <title>Masuk | <?= $row1['nama_app']; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="assets/bower_components/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="assets/plugins/iCheck/square/blue.css">
    <!-- Icon -->
    <link rel="icon" type="icon" href="assets/dist/img/icon.png">
    <!-- Custom -->
    <link rel="stylesheet" href="assets/dist/css/custom.css">
    <!-- Toastr -->
    <link rel="stylesheet" href="assets/dist/css/toastr.min.css">
</head>

<body class="hold-transition login-page" style="font-family: 'Quicksand', sans-serif;">
    <div class="login-box">
        <div class="login-logo">
            <a href="masuk"><b>Taman Bacaan Masyarakat</b></a>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body" style="border-radius: 10px;">
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISERUTEhAVFhUWFRoYFhUYFhgYGBcXFhcWFxUgGhcYHSggGRslGxYXITEhJSorLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy8lICYtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAJ8BPgMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABgcEBQECAwj/xABHEAABAwIDBQQHAwoEBQUAAAABAAIDBBEFEiEGMUFRYQdxgZETIjKhscHRQlKyFCNTYnKCkqLS8BVzwuEkM2Pi8TRDRFST/8QAGgEAAQUBAAAAAAAAAAAAAAAAAAECAwQFBv/EADkRAAEDAQUECQMDAwUBAAAAAAEAAgMRBBIhMVEFQWFxEyKBkaGxwdHwFDLhIzNCUnLxJEOSosI0/9oADAMBAAIRAxEAPwC8EREqREREIRERCEREQhEREIRERCERF1e4AXJsBvKELuo9jOOht2RG7uLuA7uZWHjOOl92RGzeLuLu7kFqaKjfK7Kwa8TwA5lc3b9rOc7obLiThUeTffu1V+GygC/Jlp7+y6wxPkflaC5x/skn5qYYRhLYRc6vO93LoOi9cMw1kDbN1cfadxP0HRZ6tbN2U2z/AKkuL/Llx49yjtFpv9VuXn80RERbSqIiLTbR422ljBtnlfpFGN7ndeTRvJ+ZCUAk0CQkAVK2VRVRx5c8jW5jZuZwGY8hfeei91VtOW1EsDpX+lnlqGDOR7Honeke2Np9hgyZeZzXN1aSfJHcoEyN9+qLGraRkrCx4uD5g8x1WSihc0OFHCoUoJBqFAMRoZKaQam17seNP/B6KSYHjgm9R9hJ7nd3XotpU07ZGlrxcH+9ORUHxfC307uJaT6r/ryK52WGXZr+lhxjOY0+bj2FaLHNtIuPwduOvzRT9FHcCx8PtHKbP3Ndwd38j8VIlu2a0x2hnSRnDy4HiqMsTo3XXIiIp1GiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIsPEa9kLczz3N4k9Ex72saXONAEoaSaBe1RO2Npc91gOP97yofjGMumNh6sfAcT1P0WNieJPmddxsB7LRuH1PVemE4W+Y8mDe75dSuVtm0Jba/oLODdPeeeg9M9FpwwNhF+TPyXnh2HvndZugHtO4D6noprQ0TIWZWDvPEnmV3pqdsbQ1gsB/evMr3W1s/ZrLK2pxecz6Dh5qnPaDIeCIiLTVdEREIWFiuIR08T5pDZrBc8ydwAHEk2AHVVgKuSomfPL7TtAN4Yz7LG9BvJ4lZe1+MGrqfRRn8zC4gcnyjRzu5uoHW55LXVcsbMkT5fRh5s5+t2s+24Aal3AdT0V+CK42pzPkqU0l40GQW42XoRJVwTEcZHs6RRtMRd0zyS6cxEFZSjuysIcH1AZlbIGsgba2WniuItOGYlz+5w5KRKpM+85WIW3WoiIo1Ki8qiBr2lrgC07wV6okIBFClUBxvB3QOuLmMnR3Loeq2eAbQ7o5j0a8/B31Ummia9pa4AgixBUHx7BXQHM25jO48W9D9Vzlosstgk+os327x83aHMclpxSstDejlz3H5v8ANT5cKF7P7QGO0cpuzcHcW9/NvwUyY4EXBuDuK2bJa47Sy8ztG8fNVRmgdE6jl2REVtQoiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIuVocbx0R3ZHq/ieDfqVBPaI4GX5DQefAap8cbnuutWTi+LsgFvaedzfmeQUMq6p8ji57rk+7oOQXSSQuJLiSTqSeK3+B4DmtJMNN7Wc+runRcpLNaNpzdGwUaN24cSdfgWo1kdmZeOfzALEwXBXTWc67Y+fF3d06qZQxNY0NaAABoAu7RbRcrpLDYI7KyjcTvOvsOCzppnSmp7kREV5QoiIhCKMbcY0YIfRxutNNdrSN7G/bf4XsOpHJSCrqWxsdI9wa1jS5xPAAXKquSqdVTvqJARc2Y0/ZYPYb363PVxU0DLxqcgoZ5LooMysDD3Nga5smhaNP1m8Lc3XIBHO3NSKk2EfM+nlqbAWc+ZnHe30UQ/VAvmPMu56e+yWECpmFS9t4oSRDfc+UaOf1a21h1ueAVhKaectNG57/nzHkoYYARV3YugFtAuyLDjxKF0hiErc7d7b6/7+Cpq4SsxERCEREQhF5yMDgQQCDoQdxC9ESIUE2gwIwnOy5j97O/p1XXAcedCQx93R+9vd06KdyNBFiLg7woTtFgBivJELx8W8Wf9vwXO2uwvsr/AKiy4DeNPxw3buGtZ7Q2dvRTdh+b/PzmcErXtDmkEHUEcV6qucFxh9O77zD7TPmORU9oqxkrA9huD5g8iOBWpYbey1NwwdvHqNR5KnabK6A45a+6yURFfVVEREIRERCEREQhEREIRERCEXBK855msaXOIAG8lQ7GsbdNdjLtj97u/p0VG22+Oytq7PcN59hxU8MDpThlqszG9oL3jhOm4v5/s/VRtctBJsBcncOaluA4EI7SSC7+DeDfqfguXay0bTmqTgO5o9/Enw0yY7MzD8leWBYFa0ko13tYeHU9en9iSoi62y2WOzMuRj3J1KyZJXSOvOReVRO1jS97g1rRck7gEqJ2xtL3uDWtFyTuAVZbTbQuqnZW3bE0+q3i483fIcFdiiMhVeSQMHFSCh20a+pLXANhd6rHHeDwLuQPu06qZqkFKNm9rXQgRzXdGNA7e5g/1D3/AAViWzb2KGKfc9WMix6OrZK0PjeHNPEf3oei9nG2pVNWlBO0DEjJIyjYdABJN11/Nt7tC49zVqKDDnVMgpoyQAAZpB9iM8j992oHieCz8QoXVL2yQ61UhL9ScjKd3sCTkMoaRxzE8CVMcAwhlLEI2nM4nNI873vO8n4AcAAFaEwZGA3P119vwqzonOkJdl6aLNpKZkTGxxtDWMaGtaNwAFgvdCVAtqdrM14ad2m58g48w08uvkoGMc80Cme8MFSszaraoR3hgN37nPG5nMDm74d+6BXN731ve/G/fzXCy8Ow2Wd2WJhceJ4DvO4LSYxsbfVUXuc8rc4PtfNDZsn51nU+uO53Hx81YdDVCWNsjQ4BwuA4WNuoUcwLY2OKz5iJHjUN+w09x9rx8lLFQndGT1ArcLXgdYrhERQqZEREIRcHVcohChW0mz2S8sI9Te5g+z1H6vTh3btLhmJyU78zDofaadzh1+qs9Q3aXZ215YW6b3sHDmWjl0XPW/Zzo3fUWfAjEgeY9R/ha9ktjXjopu8+R9+yqkeFYnHOzMw6/aad7T1+qz1VNFWPheHxusR5EciOIVgYHjTKhunqvA9ZnzHMK3s/aTbQLjsHeB5e3cq9ssToTebi3y5+62yIi1lQRERCEREQhERcoQuFi1tayFuZ5sOA4k8gFj4tizIBrq47m/XkFCq6ufK7M83PAcAOQCydo7UZZuozF+m4c/byVuz2V0vWOA8+SyMWxV87tdGj2W8B38ysOCB0jg1jSXHcB/egXrh9C+Z+Vg7zwaOqm+GYYyBtmi5PtOO8/QdFhWWwzW+QyyE03nXgN3oOavTTMgbdaMdPdY2C4K2EZnWdJz4N6D6rcIi66GFkLAyMUAWS97nm84oiIpUxQ/b+jnexrmXdE3V7BvB+8eYt5KAK71oMU2TppiXZTG4/aZYX7xuVqG0BgukKvLAXG8FV65UwqdgpB/y52u6OaW+8XWlxLZ2eAXk9GBz9I0X7g4glWhNG7IqsYnjMLBoK+WB2eJ5aeNtx7xuPiplhe2ccrfR1LchcMpe2+U3Fjfi33+Cgi5RJE1+YQyRzMlcGEUMMMYEIGU65gc2bqXfaWeqkwPHZaV3qnMwn1oydD3fdPX4qxmYzG6mdUtN2hpNuIIHsnrfTxVCWFzFdjlDwo9t1jxbemjOpH50jgDub4jU9Lc1B2tJNgLngAuZ5nPc57jdziST1OpXRaEcYY2ioyPLzVb3DsOpmetV1AH/Sju537zmXy93vCkLdsqWJoZDA/KNwAa0fG6gS4TXQh56xr5JwlLftAUzm2+f9inaP2nk+4ALW1W2VW/c5rP2W/N11pm0MpAIikIO4hjrHxsuzcOmO6CT+B30QIohuCDJId/zuW32f2mkhlvK9z2PPr3JJHJw7uXJWVFIHNDmkEEXBG4g7lVVLs1VyboHDq6zB/Nqp3sthU1NGWSyNcL3a0X9Tn6x3g8rc+arWkMzaRVTwF+RGC3yIiqqyiIiEIuVwiEKIbTbPb5oW673sHvLR8QolBO5jg5jiHA3BCt1Q7azARldPELEavA4ji4dea5/aOzM5oc8yPUceHaFsWG3ZRS5ZA+h4cexbHZ/aBs4yPs2UcODurfot+qda8gggkEagjeD3qdbNbSCW0UxAk3NduD/o74qXZ20+kpHL9246/nz8223Z5jrJHlvGn4UoREW2slERcEoQuy0ON482K7I7Ok48m9/M9FhY7tDvjhPRzx8G/VRgrndo7YuVjgOO92nL33LRs1iJ60mWnv7LvLKXEucSSd5K9sOonTPDG+J4AcSVjXU32XowyAO+1J6xPT7I8visjZ1j+rmuuyGJ+cVdtMvQsqM8gthQUTIWBjB3niTzKykRduxgYA1ooAsIkk1KIiJyRERaXG9pKelBD3gv+40i/idzfFKASaBISAKlbpYldiMUIvLI1g6nU9w3nwVWYzty+RxJqRE3gxj+HUt1JUUrNqI7ktzSO5nTzJ19ynEAH3uooTMf4hWbjW25N20zbD9I4a/ut4d58lAcUx5gcTLKXv465neJ4KKV2NzSaZsreTdPM7ytandK1mEY7Soyxz8XnsUndtS3hE7xcAven2liPtBzetrj3a+5RFEn1EiXomqxIJmvGZjg4cwbrZUuIOZDLCD6smW/QtcD7xp5Kr6SqfE7MxxB9x7xxUtoMdjfG5z/AFSwesN/dbnfkrDJmvwdh+FC6MtxC2xWqq8ehZpmzHk3X37lHsSxWSd2UXDeDBx/a5/BY7YIx7ctz91gzfzEhvldMfaP6e8pwiH8lvDtS39CbftD6LKpdooXaElh/WGnmPmo4DTfdm78zPhZPyaF3sTZT92Rtv523CYJpNQU4xt0ViYbi0sVnQzOA32Bu0/u7ipVh23jhYTxX/WZof4T9VSMck9ObgloPix3yK29JtQN0kdurdfcd3mnX4n4PFCkAkZ9pV7U21VI+357KTwcC332t71vFQMOMQO3StHR3q/FTvY3asC0M0rTHb1Hl3s8gTy6nco5IABVhqpWTGtHiisNF1a8EXBuDuIXZVlYRERCERFEtq9oHxO9DEbOtdzt5F9wF/j1UFotDIGF78lNBA+Z9xmalbnAC5NgtXWY7TMBDpmnm0et+G6raprHyG73ud+04n4rwWLJts/7bO/2HutZmx2/zd3fn2XrMW5jl9m5y919PcvO67RRuccrWlxO4AEnyC2cezdW7UQO8S0e4lYrYXyfa0nkCVrukYz7nAczRb/ZjafNaKd2u5kh48g7r14/GYqsDsvWfoT/ABM/qUq2dnqmN9HPC/1R6rtCbcjY+9dHs+1TD9OdruDiD44eKwbdZof3IXDiAR3jHw7VIZHhoJJAA1JO4BQ7HceMt2RkiPieLvoFlY8KqY5WxOEYOg09bqdfILT/AOC1H6F3u+qp7TtlokJihY67vN048sMvPlm2ywRto95FdKjBYF0WacHqP0D/ACXBwio/QP8A4Vg/Szf0O/4n2Wl0jP6h3hYSzKPFJovYkIH3d48juWI9pBsQQRvB0K6JjHvidVpIPDBOLWuFCKhb4bV1HJh/dP1WVR7WOzASsGX7zb3Hgd6i10urrNqWtprfJ54hQmxwu/j3K1GuBFxuO4rstHsnWZ4MpOsZy+G9v08FvF2UEoljbIN4qsKRhY8tO5YmJ1zIIZJpDZkbHPd3NF/NfLFZUOlkfK/2pHue79p7i4+8r6ixfB4KpgjnZnYDmy5nN1G6+Ui61LNgsNbuo2+LpHfFxU1TooiAV83W6LnKeRX0wzZLDgbCip79Y2k+9ZkWz9G32aSAd0TPoipSXAvlvKeS7tgcdzSvqplBC3dDGO5jR8l7tjA3ADuCKlLcHz/C+VosLmd7MTz3NcfgFlR7OVZ3Us57oZD/AKV9Qokx1S3W6L5fm2dnis6ohlhjvbO+J7deQuN5Xk6vc0gRXYxu5vPmX/eJ6r6gnha9pa9oc0ixa4AgjqDvUdm2Bw1xuaNo6NdI0fwtcAnBzgMElxqoRmHmod/w8by8+1C1rnHqW5QfV6HcvV+y1YN9JUf/AIS/0r6OwvB6emaWwQMjB35WgE953nxWekJJxQGtC+WJMEqW76eUd8bx8WrGfSvG9hHeF9YLgi+9JUoLWr5Pjke32SRzF9D3jcV5vudbeQA+AV79pe0X5CISyNji4m7SG6jhvaeRUSpu0ykd/wA7D4TzPomfHX4KL6g1Iuk0NKgVxoDuJO/RP6BtB1gK44mnpTxVaZTyXFlcdDtPgc1g+jgYT/0mD4tapZBsjhczA9lJCWncWgj4FKydrjQZ6GoPcRVI6AtFTlrgR3glabsXxX0tB6En1qd5bw9h93s8NXD91WCtDheyVFTS+lggyPsRcSSEWOmrS4g+S3ykSAURERKhFWO1xvWS97fwNVnKr9rhasl72/gasfbX7Lf7vQrV2R+87+31C1F0uuqysMjzTRtP2pGjzcAuaa28QNV0RwBJVi7NYS2nhboPSOAL3cbnW1+QW6XK4XcxxtjaGNyC4t73SOL3ZlERFImLlcIiEIuVwiEKF7ZUobI14Htg3722+RHko4VNttIrwB33XjyII+NlCLri9rxXLU6m+h78/FdBYXXoRwwS6LrdFmq4t3s3XOjE5aAT6IuAO67D9CVFanthlPsQgeAHxzLfYIM0wZe2drmX/aY4D32XhT9jUF7yVcpub2a1rRr33XUbIrJDdN6gqMDTPHUa6rI2h1H1FKnUV3U0OiidT2qVzt1h4/0gLU1O3te/fNbzP4iVgbWYY2mq5YWXysdYXNzppqfBTbsYwqmqDOJ4I5C3KW52g2vod60+hguB12tdST5kqh0s14tvUpoB4UAXbsfxqWauc2WTNeI20AtqL7grrUSxTFMOw5wvFHG+1xlY1psev0uo/J2wUwdYRkjnZ39KGPjjJawb8mtJAwGgpVOe17gC87s3ECuJ1Ks1cqB47t+yOkjq4Gh7HOLXAi5B0txHNQmu7W53M9RuVxNraAAc7gX8Oif0977Gl3KgGQO8jVNMV373Ad58gVeSL5/Z2mVz4nR6mRxGXLc9/wCt4ArBwXbatiqGF0hPrgOaRbebG9vgUhllAJuYDOpFeyla9pHCqAyM0F/PLA07SaU8dV9Dz1DGC73taOZIHxWD/j9Ne3pm+Rt52sq27R6OaaqzCoEEORuZxJBN2tIsBqePEBVjjNPCx49DOZfvPItY8LG+qijndK8sYQM9zjlqeqB4p74hGwPcCct7RnoMSab19JYvtHT0rWulf6rhdrhax8SQFH6ztNomsL2kuF7DUam1z7Nzy81XGKSumwGF7ySWTubc8szQFh9nOyTMQlkbI9zWRszera5JNhv4JWukeCS6lDSgAOmRPE4YJHXGUAbWorUkjCpzA8cVZeBdqNNUTNiLSwuNgTff4hWEvlR0HoasMv7EwAPQOFvcvqWGQFgdwyg+66liONLxIIBBNK410AGm5RvyyoQSDStMKak8VSHbZX56xkd/YZ8d3vzLT7CYHRVIl/LJnR6gR5Trfebix01HDgtdtzX+nrpn3+1YfH4krZ4d2b1lRSsqYjGWvbmyOJa6w8LFNbUwijqE1dkTgTXcRuI3pT+6cKgUG4bqbwd4JyWi2lw+KnqHxQymRg3OIseO+3H6q3+xCSR1FJmJLRLZl+7X5BUrDGxkuWdrg1rrODSARY2PA3Vt4htiKBkEFBTl0Xog6zWlxBOpLjbUknf0KJJQy401ccwcMcDlU9px03lLHGXX3DAZEaYjPDsy13BWuiqXDu131w2ohLRfW4sR366eSsaXHIGxNldIA14u3iSO4J4tDMb3VpjjhhrXI9hPFJ0Tv448sVtEWlpdp6WQ2bMPG4HnuW4Y64uDcc0+OVkn2EHkapr43s+4EcxRdlWe2otWSdQ0/wAoVmqtNvB/xZ6sb8CFnbYH+n7R6rR2P/8AR2H0Ueuths9rVQf5rfitbdbHZ0/8VB/mt+K52D91vMeYXRzD9N3I+St1cIi7dcQiIiEIiIhCIiIQtfj0OemlH6hI72+sPgq2VrPbcEHiLeaqqePI5zTvaSPI2XNbei6zH8x6+62dlvwc3kV0ul11ul1z61lmYTJlniPKRv4grSVSQvs5p5EHyKtpdNsF3UeOIPePwsbares08CvnPtVjy4nL118y5SLsHltU1DecTT5OK0/bGy2JO6sb81kdiU2XEC370TvdqtaM/oDg6nc+izXH9c8R/wCFve1Sej/KWunzSOY2zYmmwubE5rWJ8wO9VtjFU2UB8dK2GMGwLR7RPAncToVO+1DYqrfVuqIInSskH2dXNOt7jfbVYp2SxWspWxvphHke3IHEMAYGuBNrm2pGllC0FjmvNSbxqKmjak5NGeeJx4KZzrzXNFAKDcKuoBmd2O7DtxWupfWwCT9Sqb79fku3ZlRxyflgewOIpjluAba62vu3KT4fsJPDh89NUz08Rkka9ri/1W5WkG9wOawNnafD8MdK5+LxSmRhjLYo3SWuCN7CeJ6JxY5zJGgHE1HemtLWvjcSMBQ93uop2cEDE6W/6T5FY20zMlfKPuyg/hK3lDWYPSytmjdXTPY7M02ijbfuOtl5YltPQySvl/wkPc83Lpal5/kY0AeamuuMvSUwpTMa8zhgog5oiuV31WL2hzzOqrSk5cjXMHAgtGo58u4BYuKx0xp43U0bhaTI5ztXPdkzHw6BbjE+0KWdrWOoaItYAGB8TpC0DQC7nrHpu0CsiFoW08Q5R08bfkUxlnexsbQaXeJodajWu/XcnOnY5z3EVvd40odKbuWi2FDRTS4IYmQyOf8AlFw0MdmILr6C27RSTscwSqpp5nT00kbXxgAuFrkG/NQ89peKf/at3RRf0rsztNxQf/JB74o/k1SNhLa45m9ly4pjpgaYZCi3GJdmeITVUkrWxMYX5m5pNdLcGg23K3KmKUUpYxoMvog21wBfKAdT4ql4O1vEmbxBJ0MZBPi1wV8x3sL77C/fxQIKNu1OV3s7kvTVdeAGde1fNmJ7EYmxznSUkhuSSWWeLk3PskleTNoK+nb6Ml7ABaz2FtgNOQv4r6MxvEW01PLO8Etijc8gbzlF7Dqd3iq8HbFRP0lo57dRE4fiSvhDwGuAIGo+UwSNkuElriCdD8rjx91TtPBJUSEMBe5xJcRr1cTyHG631BjVZM5sNO4NAbZo9Ueq0AXLnK1aHtIwcgtBMQdoQYHAEHfcxghaVux2DVU3pKbEGtObMYmyMI33tldZwB5KOeK+OswGgwwrQ8iQD6UToX3T1XEVOONKjmASPXsVYYsyZ9QWTPD5LtZcWtrawFgPvLabbVrzKKe5yQtazLzIH+/mSrBh7KXNrGVH5U17BKJHNLLEi99CCR/4Wq7Sdgak1L6mljMrZDmc1vtsd3cR3JjWdeMuFA0aUAcaY0G4AHlVPc7qvANS4643RXCutadyxYuyarbGyaOdheQ1xjGZpANjYP4m3ctptjLWPma2mmZHHGwM9Zw1LQBuAPG/msLZqpxiVxikjmaxkTnes2RmYtGgFzl1PABQGkY2aotVSvbckE5S52a9g0Dh5cFXkD5nEvoLoqcA8HPICldccsMMVOwxxNoyvWP9lMsya07M8VJottsQo5cr5g+1iQDcEfC/eFMdqqz00kUtrekgY63fmVVHD2mrFPHcgyiME7zqA7cOd1bm3MIZLEwbmwMaP3S4KC3saLOLujSdwxyoKkDfkrmzHudaSHbrwG84Z40FVHLrPwF1qqD/ADWfiC191nYF/wCqh/zo/wAbViRDrt5jzXQSDqO5HyVxIiLtiuFRERCEREQhEREIRVttNFkqpRzOYfvAE++6slQbbuK0zH/eZb+E/wDcsjbUd6zXtCPHD1Wjsx1Jqag+/oo1dcLhcrk10CEq3IzcA9AqVxLE44G5pCelgSSumMdrlS5uSlibCAAM7vXedN4Hst/mXR7CjcL7qYGmPKqxdrvb1G1xx9FYm0OxdBUSmpq7mw1JkLGADut7yo3/AI3gGHPz07Q+VoIBhzSHqPSOOT3qpMUxWepdmqJ5JTwzuJA7m7m+ACw1vCJuVPmaxjK5WjivbLKbimpGMHB0ri8/wNsB5lRLE9vMSnvmrHtB+zFaIebLO8yo2ikTKld55XPOZ7nPdzcS4+Z1XRAFvsP2UmkALi2MHn6x8hp71DNaIoRWRwHzTNPihklNGCq0K5a0k2AJPIalWpgnZgHAOcMw5vfYeDWfNTPDthIIxq7wY0MHzJVf6x7xWKMkauN0ep8FZ+kaz9yQA6DrH28VRNNgNS/dC4Dm6zfxLa0mxM797mjo0OefIAK/abAqdm6Fp6u9b8S2EcYaLAADkBZF22Oze1vIV8XYf9Uv+lbk1zuZA8vdUfSdmErt4mP7rYx/MtvD2VDjF/FL/SrcXKT6R5+6V57QPIBO6dg+2JnaCfMqtsG7NIo52SSQsysdmtnc65GrdDpvtvUP7QNpayCulijqHtZckC97Xc4ce5XyvnjtdjtiL+rf9Tz80dA1jmNNXAk/ca/xOvJIZi5j3CjaAfaKb/yt5sPDUYpR1sD6g5nOi9c8GtdnI0HEtt4ldpuxqb7NSzxB/wBlhdlW0DKOKqkkaS27L24aHop0O02kELZnNeGPcWtIudW3B0tcbik6SOMlgcW0NKAYY4gYAjI8UXHvaHEA1Fak44YHeFAp+yKuHsvjd42+a1dT2aYi3/2M37Jv8l9A4ZWtnhZK0ENe0OAO+x3LMVhoecQ89oHsCoSGZFni71JHgvmuGmxaiPqflUVuDXOLf4Llp8Qt5h3aviMGlREyYfrtMT/4mi38qvcrCqcKgk9uGN3e0fFOrJXce8ep8khazdUdx8KBQrBu1ygmsJhJTu/WGdn8bL6dSApJHh2HVlp2x08xvcStyuN/2m63WBiHZ1hst704YTxYS0qOv7JhG70lFWywv4HX8TSCU0moo9vkR40PglAocHeYPhXzUli2Bw9k7J44MkjH5wWudYnq0kg71xtRs1JVTNex7GgMDbOve4LjwH6y0sVRjtEPzzYK2IfaziKW37VreYPet1s5t5S1cnoQHxTjfE9t/J7LtI8Qo3xQzN6M5aYg4eKlimlhcHtzx3A5+C1I2Bm/Tx+Tlk4fsTJHLHIZmEMe1xAB1ykH5KcIom7Ns7TUDxKsO2paXAgu8AuVwiK+s9EREIX/2Q==" height="80px" width="80px" style="display: block; margin-left: auto; margin-right: auto; margin-top: -12px; margin-bottom: 5px;">
            <form name="formLogin" action="function/Process.php?aksi=masuk" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" name="username" id="username" placeholder="Nama Pengguna">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Kata Sandi">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Masuk</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <div class="social-auth-links text-center">
                <p style="font-size: 11px;">- ATAU -</p>
                <div class="row">
                    <div class="col-xs-12">
                        <button type="button" onclick="Register()" class="btn btn-block btn-warning btn-flat"><i class="fa fa-user-plus"></i> Daftar sebagai member</button>
                    </div>
                </div>
            </div>

            <!-- <p style="text-align: center; font-size: 13px;">Hak Cipta &copy; <?= date('Y'); ?> .<?= $row1['nama_app']; ?> by FA Team.</p> -->
            <!-- <br><center><p>Repost by Abid Taufiqur Rohman</p></center> -->
            

        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->

    <!-- jQuery 3 -->
    <script src="assets/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- -->
    <script src="assets/json/lottie-player.js"></script>
    <!-- Fungsi mengarahkan kehalaman pendaftaran -->
    <script>
        function Register() {
            window.location.href = "pendaftaran";
        }
    </script>
    <!-- Fungsi mengarahkan kehalaman lupa password -->
    <script>
        function ForgotPassword() {
            window.location.href = "lupa-password";
        }
    </script>
    <!-- Sweet Alert -->
    <script src="assets/dist/js/sweetalert.min.js"></script>
    <!-- Pesan Masuk Dulu -->
    <script>
        <?php
        if (isset($_SESSION['masuk_dulu']) && $_SESSION['masuk_dulu'] <> '') {
            echo "swal({
                icon: 'error',
                title: 'Peringatan',
                text: '$_SESSION[masuk_dulu]',
                buttons: false,
                timer: 3000
              })";
        }
        $_SESSION['masuk_dulu'] = '';
        ?>
    </script>
    <!-- Pesan Pendaftaran -->
    <script>
        <?php
        if (isset($_SESSION['berhasil']) && $_SESSION['berhasil'] <> '') {
            echo "swal({
                icon: 'success',
                title: 'Berhasil',
                text: '$_SESSION[berhasil]',
                buttons: false,
                timer: 3000
              })";
        }
        $_SESSION['berhasil'] = '';
        ?>
    </script>
    <script>
        <?php
        if (isset($_SESSION['gagal']) && $_SESSION['gagal'] <> '') {
            echo "swal({
                icon: 'error',
                title: 'Peringatan',
                text: '$_SESSION[gagal]',
                buttons: false,
                timer: 3000
              })";
        }
        $_SESSION['gagal'] = '';
        ?>
    </script>
    <!-- -->
    <script>
        <?php
        if (isset($_SESSION['gagal_login']) && $_SESSION['gagal_login'] <> '') {
            echo "swal({
                icon: 'error',
                title: 'Peringatan',
                text: '$_SESSION[gagal_login]',
                buttons: false,
                timer: 3000
              })";
        }
        $_SESSION['gagal_login'] = '';
        ?>
    </script>
    <script>
        <?php
        if (isset($_SESSION['berhasil_keluar']) && $_SESSION['berhasil_keluar'] <> '') {
            echo "swal({
            icon: 'success',
            title: 'Berhasil',
            text: '$_SESSION[berhasil_keluar]',
            buttons: false,
            timer: 3000
        })";
        }
        $_SESSION['berhasil_keluar'] = '';
        ?>
    </script>
    <!-- Toastr -->
    <script src="assets/dist/js/toastr.min.js"></script>
    <!-- -->
    <script>
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-top-right",
            "preventDuplicates": true,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    </script>
    <!-- -->
    <script>
        function validateForm() {
            if (document.forms["formLogin"]["username"].value == "") {
                toastr.error("Nama Pengguna harus diisi !!");
                document.forms["formLogin"]["username"].focus();
                return false;
            }
            if (document.forms["formLogin"]["password"].value == "") {
                toastr.error("Kata Sandi harus diisi !!");
                document.forms["formLogin"]["password"].focus();
                return false;
            }
        }
    </script>
</body>

</html>