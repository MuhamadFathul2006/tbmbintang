<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Versi</b> 1.1
    </div>
    <strong>Hak Cipta &copy; <?= date('Y'); ?>. Muhamad Fathul Bari</strong> 
    
</footer>